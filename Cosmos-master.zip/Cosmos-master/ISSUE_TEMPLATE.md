Please consider submitting the following information (if relevant):

* Library setup method: file, Carthage, CocoaPods or Swift Package Manager.
* Version of the library. Example: 8.0.
* Xcode version. Example: 8.3.3.
* OS version. Example: iOS 10.3.2.